export { default as Apple } from "./Apple/Apple";
export { default as Facebook } from "./Facebook/Facebook";
export { default as Sega } from "./Sega/Sega";
