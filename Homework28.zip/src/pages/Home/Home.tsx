function Home() {
  return <>Home</>;
}

export default Home;
