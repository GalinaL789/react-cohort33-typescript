import styled from "@emotion/styled";
export const WeatherErrorWrapper = styled.div`
width:400px;
height:70px;
padding-left:80px;
font-size:28px;
color:red;
`;