import styled from "@emotion/styled";
export const WeatherInfoWrapper = styled.div`
display:flex;
width:350px;
height:70px;
padding-left:10px;
font-size:28px;
color:white;
`;