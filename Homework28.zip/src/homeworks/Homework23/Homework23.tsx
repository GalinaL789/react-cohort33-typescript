import EmployeeForm from "components/EmployeeForm/EmployeeForm";

import { Homework23Wrapper } from "./styles";

function Homework23() {
  return (
    <Homework23Wrapper>
      <EmployeeForm />
    </Homework23Wrapper>
  );
}

export default Homework23;
