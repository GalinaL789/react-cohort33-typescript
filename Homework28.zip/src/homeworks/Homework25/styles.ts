import styled from "@emotion/styled";

export const Homework25Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
`;
