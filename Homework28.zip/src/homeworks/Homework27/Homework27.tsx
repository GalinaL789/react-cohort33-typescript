import BlogManagement from "./components/BlogManagement/BlogManagement";

function Homework27() {
  return <BlogManagement />;
}

export default Homework27;