import Main from "lessons/Lesson27/Main/Main";

import { Lesson27Wrapper } from "./styles";

function Lesson27() {
  return (
    <Lesson27Wrapper>
      <Main />
    </Lesson27Wrapper>
  );
}

export default Lesson27;
