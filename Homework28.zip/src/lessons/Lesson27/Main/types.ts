export interface UserData {
  fullName: string;
  age: number;
  email: string;
}
